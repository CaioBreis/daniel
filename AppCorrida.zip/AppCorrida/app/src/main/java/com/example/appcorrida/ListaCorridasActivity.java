package com.example.appcorrida;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

public class ListaCorridasActivity extends AppCompatActivity {

    private AppDatabaseHelper dbHelper;
    private CorridaCursorAdapter corridaCursorAdapter;
    private ListView listViewCorridas;
    private TextView tvEmptyListMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_corridas);

        dbHelper = new AppDatabaseHelper(this);
        listViewCorridas = findViewById(R.id.listViewCorridas);
        tvEmptyListMessage = findViewById(R.id.tvEmptyListMessage);

        // Não carregue os dados diretamente no onCreate para evitar que o CursorAdapter
        // seja inicializado com um Cursor inválido antes do onStart.
        // O Cursor será carregado em onStart ou onResume.
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Recarrega os dados do Cursor sempre que a atividade se torna visível
        loadCorridasData();
    }

    private void loadCorridasData() {
        Cursor cursor = dbHelper.getAllCorridas();

        if (cursor != null && cursor.getCount() > 0) {
            tvEmptyListMessage.setVisibility(View.GONE);
            listViewCorridas.setVisibility(View.VISIBLE);

            if (corridaCursorAdapter == null) {
                corridaCursorAdapter = new CorridaCursorAdapter(this, cursor);
                listViewCorridas.setAdapter(corridaCursorAdapter);
            } else {
                corridaCursorAdapter.changeCursor(cursor); // Atualiza o Cursor existente
            }
        } else {
            // Nenhuma corrida encontrada, mostra a mensagem de lista vazia
            tvEmptyListMessage.setVisibility(View.VISIBLE);
            listViewCorridas.setVisibility(View.GONE);
            if (corridaCursorAdapter != null) {
                corridaCursorAdapter.changeCursor(null); // Limpa o adapter se não houver dados
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Fechar o Cursor quando a atividade não estiver mais visível
        if (corridaCursorAdapter != null) {
            Cursor oldCursor = corridaCursorAdapter.getCursor();
            if (oldCursor != null) {
                oldCursor.close();
            }
            // Não defina o adapter como null aqui, apenas feche o cursor.
            // O adapter será recarregado em onStart ou onResume.
        }
    }

    // Opcional: se você quiser recarregar os dados sempre que a atividade voltar ao foco
    // @Override
    // protected void onResume() {
    //     super.onResume();
    //     loadCorridasData();
    // }
}