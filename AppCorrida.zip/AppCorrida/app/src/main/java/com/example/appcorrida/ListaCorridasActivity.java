package com.example.appcorrida;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView; // Importar TextView
import android.widget.Toast;

public class ListaCorridasActivity extends AppCompatActivity {

    private ListView listViewCorridas;
    private TextView tvEmptyListMessage; // Nova referência para o TextView da mensagem vazia
    private AppDatabaseHelper dbHelper;
    private CorridaCursorAdapter cursorAdapter;
    private Cursor corridasCursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_corridas);

        listViewCorridas = findViewById(R.id.listViewCorridas);
        tvEmptyListMessage = findViewById(R.id.tvEmptyListMessage); // Inicializar o TextView da mensagem vazia
        dbHelper = new AppDatabaseHelper(this);

        listViewCorridas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(ListaCorridasActivity.this, "Corrida clicada! ID: " + id, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCorridasFromDatabase();
    }

    private void loadCorridasFromDatabase() {
        if (corridasCursor != null && !corridasCursor.isClosed()) {
            corridasCursor.close();
        }
        corridasCursor = dbHelper.getAllCorridas();

        if (corridasCursor != null && corridasCursor.getCount() > 0) { // Verificar se o cursor não é null e tem dados
            if (cursorAdapter == null) {
                cursorAdapter = new CorridaCursorAdapter(this, corridasCursor);
                listViewCorridas.setAdapter(cursorAdapter);
            } else {
                cursorAdapter.changeCursor(corridasCursor);
            }
            listViewCorridas.setVisibility(View.VISIBLE); // Mostra a lista
            tvEmptyListMessage.setVisibility(View.GONE);  // Esconde a mensagem
        } else {
            // Nenhuma corrida encontrada
            if (cursorAdapter != null) {
                cursorAdapter.changeCursor(null); // Limpa o adaptador para garantir que a lista esteja vazia
            } else {
                listViewCorridas.setAdapter(null); // Se o adaptador ainda não foi criado, defina como null
            }
            listViewCorridas.setVisibility(View.GONE); // Esconde a lista
            tvEmptyListMessage.setVisibility(View.VISIBLE); // Mostra a mensagem
            Toast.makeText(this, "Nenhuma corrida salva ainda.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (corridasCursor != null && !corridasCursor.isClosed()) {
            corridasCursor.close();
        }
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}