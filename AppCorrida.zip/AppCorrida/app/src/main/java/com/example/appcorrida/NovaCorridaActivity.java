// AppCorrida/app/src/main/java/com/example/appcorrida/NovaCorridaActivity.java
package com.example.appcorrida;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;

public class NovaCorridaActivity extends AppCompatActivity implements LocationListener, OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private Button btnStartStop;
    private TextView tvStatus;
    private LocationManager locationManager;
    private boolean isRunning = false;
    private List<Location> points = new ArrayList<>();

    private GoogleMap googleMap;
    private Marker currentLocationMarker;
    private Polyline routePolyline;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_corrida);

        btnStartStop = findViewById(R.id.btnStartStop);
        tvStatus = findViewById(R.id.tvStatus);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // Obtenha o SupportMapFragment e seja notificado quando o mapa estiver pronto para uso.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        btnStartStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRunning) {
                    stopTracking();
                } else {
                    startTracking();
                }
            }
        });
    }

    private void startTracking() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        isRunning = true;
        btnStartStop.setText("Parar Corrida");
        tvStatus.setText("Status: Gravando...");
        points.clear(); // Limpa os pontos de corridas anteriores

        // Limpa o mapa e a polilinha, se existirem
        if (googleMap != null) {
            googleMap.clear();
            currentLocationMarker = null;
            routePolyline = null;
        }

        // Solicita atualizações de localização
        // Min. tempo entre atualizações (ms), Min. distância entre atualizações (metros)
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);
        Toast.makeText(this, "Rastreamento iniciado!", Toast.LENGTH_SHORT).show();
    }

    private void stopTracking() {
        isRunning = false;
        btnStartStop.setText("Iniciar Corrida");
        tvStatus.setText("Status: Parado");

        locationManager.removeUpdates(this);
        Toast.makeText(this, "Rastreamento parado. Pontos coletados: " + points.size(), Toast.LENGTH_LONG).show();

        // TODO: Na Etapa 4, salvaremos esses 'points' no banco de dados
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startTracking(); // Tenta iniciar novamente se a permissão foi concedida
            } else {
                Toast.makeText(this, "Permissão de localização negada. Não é possível rastrear a corrida.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        // Este método é chamado sempre que uma nova localização é recebida
        points.add(location);
        tvStatus.setText("Status: Gravando... Pontos: " + points.size() + " Lat: " + String.format("%.4f", location.getLatitude()) + " Lon: " + String.format("%.4f", location.getLongitude()));

        if (googleMap != null) {
            LatLng newLatLng = new LatLng(location.getLatitude(), location.getLongitude());

            // Atualiza ou cria o marcador de localização atual
            if (currentLocationMarker == null) {
                currentLocationMarker = googleMap.addMarker(new MarkerOptions().position(newLatLng).title("Sua Posição"));
            } else {
                currentLocationMarker.setPosition(newLatLng);
            }

            // Move a câmera para a nova localização
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(newLatLng, 17)); // Zoom 17 é bom para ruas

            // Desenha o tracejado da rota
            if (routePolyline == null) {
                PolylineOptions polylineOptions = new PolylineOptions()
                        .add(newLatLng)
                        .color(ContextCompat.getColor(this, R.color.purple_500)) // Definir uma cor para a linha
                        .width(10); // Definir a largura da linha
                routePolyline = googleMap.addPolyline(polylineOptions);
            } else {
                List<LatLng> currentPoints = routePolyline.getPoints();
                currentPoints.add(newLatLng);
                routePolyline.setPoints(currentPoints);
            }
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // Chamado quando o status do provedor muda (habilitado, desabilitado, etc.)
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        // Chamado quando o provedor de localização é habilitado pelo usuário
        Toast.makeText(this, "GPS habilitado!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        // Chamado quando o provedor de localização é desabilitado pelo usuário
        Toast.makeText(this, "GPS desabilitado. Por favor, habilite o GPS para rastrear.", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // É uma boa prática parar as atualizações de localização quando a atividade não está em foco
        if (isRunning) {
            locationManager.removeUpdates(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Retomar as atualizações de localização se a corrida ainda estiver em andamento
        if (isRunning) {
            // Verificar permissões novamente antes de iniciar, caso o usuário tenha revogado
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                startTracking(); // Reinicia o rastreamento se a permissão ainda estiver lá
            }
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        // Opcional: Habilitar o botão de localização do usuário no mapa
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);
            googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        }

        // Definir uma posição inicial no mapa (por exemplo, Salvador - Bahia, Brasil)
        // Isso é apenas para que o mapa não comece vazio se ainda não tiver uma localização.
        LatLng salvador = new LatLng(-12.9714, -38.5011);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(salvador, 10)); // Zoom adequado para uma cidade
    }
}