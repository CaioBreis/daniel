package com.example.appcorrida;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import java.util.Locale;

public class CorridaCursorAdapter extends CursorAdapter {

    public CorridaCursorAdapter(Context context, Cursor c) {
        super(context, c, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item_corrida, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView tvCorridaData = view.findViewById(R.id.tvCorridaData);
        TextView tvCorridaDuracao = view.findViewById(R.id.tvCorridaDuracao);
        TextView tvCorridaDistancia = view.findViewById(R.id.tvCorridaDistancia);
        TextView tvCorridaElevacao = view.findViewById(R.id.tvCorridaElevacao);

        String data = cursor.getString(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_DATA_HORA_INICIO));
        long duracaoSegundos = cursor.getLong(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_DURACAO_SEGUNDOS));
        double distanciaMetros = cursor.getDouble(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_DISTANCIA_METROS));
        double ganhoElevacao = cursor.getDouble(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_GANHO_ELEVACAO));

        int seconds = (int) (duracaoSegundos % 60);
        int minutes = (int) ((duracaoSegundos / 60) % 60);
        int hours = (int) (duracaoSegundos / 3600);
        String formattedDuration = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);

        // Usando getString para formatar diretamente do recurso
        tvCorridaData.setText(context.getString(R.string.run_data_label, data));
        tvCorridaDuracao.setText(context.getString(R.string.duration_label, hours, minutes, seconds));
        tvCorridaDistancia.setText(context.getString(R.string.distance_label, distanciaMetros / 1000));
        tvCorridaElevacao.setText(context.getString(R.string.elevation_gain_label, ganhoElevacao));
    }
}