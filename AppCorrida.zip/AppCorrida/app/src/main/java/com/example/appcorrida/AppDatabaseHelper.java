//interação do banco de dados com o aplicativo
package com.example.appcorrida;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AppDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "corridas.db";
    private static final int DATABASE_VERSION = 2; // Mantém a versão 2 para que a estrutura atual do DB seja usada

    // Tabela Corrida
    public static final String TABLE_CORRIDA = "Corrida";
    public static final String COLUMN_CORRIDA_ID = "id";
    public static final String COLUMN_DATA_HORA_INICIO = "data_hora_inicio";
    public static final String COLUMN_DURACAO_SEGUNDOS = "duracao_segundos";
    public static final String COLUMN_DISTANCIA_METROS = "distancia_metros";
    public static final String COLUMN_GANHO_ELEVACAO = "ganho_elevacao";

    // Tabela Localizacao
    public static final String TABLE_LOCALIZACAO = "Localizacao";
    public static final String COLUMN_LOCALIZACAO_ID = "id";
    public static final String COLUMN_CORRIDA_ID_FK = "corrida_id";
    public static final String COLUMN_LATITUDE = "latitude";
    public static final String COLUMN_LONGITUDE = "longitude";
    public static final String COLUMN_ELEVACAO = "elevacao";
    public static final String COLUMN_TEMPO_PONTO_OFFSET = "tempo_ponto_offset";

    // SQL para criar a tabela de Corrida
    private static final String SQL_CREATE_TABLE_CORRIDA =
            "CREATE TABLE " + TABLE_CORRIDA + " (" +
                    COLUMN_CORRIDA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_DATA_HORA_INICIO + " TEXT," +
                    COLUMN_DURACAO_SEGUNDOS + " INTEGER," +
                    COLUMN_DISTANCIA_METROS + " REAL," +
                    COLUMN_GANHO_ELEVACAO + " REAL);";

    // SQL para criar a tabela de Localizacao
    private static final String SQL_CREATE_TABLE_LOCALIZACAO =
            "CREATE TABLE " + TABLE_LOCALIZACAO + " (" +
                    COLUMN_LOCALIZACAO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_CORRIDA_ID_FK + " INTEGER NOT NULL," +
                    COLUMN_LATITUDE + " REAL," +
                    COLUMN_LONGITUDE + " REAL," +
                    COLUMN_ELEVACAO + " REAL," +
                    COLUMN_TEMPO_PONTO_OFFSET + " INTEGER," +
                    "FOREIGN KEY (" + COLUMN_CORRIDA_ID_FK + ") REFERENCES " +
                    TABLE_CORRIDA + "(" + COLUMN_CORRIDA_ID + ") ON DELETE CASCADE);";

    public AppDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_CORRIDA);
        db.execSQL(SQL_CREATE_TABLE_LOCALIZACAO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOCALIZACAO);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CORRIDA);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }

    public long insertCorrida(long duracao, double distancia, double elevacaoGanho) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        values.put(COLUMN_DATA_HORA_INICIO, currentTime);
        values.put(COLUMN_DURACAO_SEGUNDOS, duracao);
        values.put(COLUMN_DISTANCIA_METROS, distancia);
        values.put(COLUMN_GANHO_ELEVACAO, elevacaoGanho);

        long corridaId = db.insert(TABLE_CORRIDA, null, values);
        db.close();
        return corridaId;
    }

    public void insertPontosCorrida(long corridaId, List<Location> points, long startTimeMillis) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            for (Location location : points) {
                ContentValues values = new ContentValues();
                values.put(COLUMN_CORRIDA_ID_FK, corridaId);
                values.put(COLUMN_LATITUDE, location.getLatitude());
                values.put(COLUMN_LONGITUDE, location.getLongitude());
                values.put(COLUMN_ELEVACAO, location.getAltitude());
                long timeOffset = (location.getElapsedRealtimeNanos() / 1_000_000L) - startTimeMillis;
                values.put(COLUMN_TEMPO_PONTO_OFFSET, timeOffset);

                db.insert(TABLE_LOCALIZACAO, null, values);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    public Cursor getAllCorridas() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                TABLE_CORRIDA,
                new String[]{
                        COLUMN_CORRIDA_ID,
                        COLUMN_DATA_HORA_INICIO,
                        COLUMN_DURACAO_SEGUNDOS,
                        COLUMN_DISTANCIA_METROS,
                        COLUMN_GANHO_ELEVACAO
                },
                null, null, null, null,
                COLUMN_DATA_HORA_INICIO + " DESC"
        );
    }

    public Cursor getPontosByCorridaId(long corridaId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_CORRIDA_ID_FK + " = ?";
        String[] selectionArgs = { String.valueOf(corridaId) };
        String orderBy = COLUMN_TEMPO_PONTO_OFFSET + " ASC";

        return db.query(
                TABLE_LOCALIZACAO,
                new String[]{
                        COLUMN_LOCALIZACAO_ID,
                        COLUMN_LATITUDE,
                        COLUMN_LONGITUDE,
                        COLUMN_ELEVACAO,
                        COLUMN_TEMPO_PONTO_OFFSET
                },
                selection,
                selectionArgs,
                null, null,
                orderBy
        );
    }
}