//Cria e atualiza o banco de dados com as tabelas CORRIDA e LOCALIZAÇÃO.
//Estende o SQLiteOpenHelper.
package com.example.appcorrida;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDatabaseHelper extends SQLiteOpenHelper{
    public static final String DATABASE_NAME = "corridas.db";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_CORRIDA = "Corrida";
    public static final String TABLE_LOCALIZACAO = "Localizacao";

    public AppDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tabela de Corrida
        String CREATE_TABLE_CORRIDA = "CREATE TABLE " + TABLE_CORRIDA + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "data_hora_inicio TEXT, " +
                "duracao_segundos INTEGER, " +
                "distancia_metros REAL, " +
                "ganho_elevacao REAL" +
                ");";

        // Tabela de Localizacao
        String CREATE_TABLE_LOCALIZACAO = "CREATE TABLE " + TABLE_LOCALIZACAO + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "corrida_id INTEGER, " +
                "latitude REAL, " +
                "longitude REAL, " +
                "elevacao REAL, " +
                "timestamp TEXT, " +
                "FOREIGN KEY(corrida_id) REFERENCES " + TABLE_CORRIDA + "(id)" +
                ");";

        db.execSQL(CREATE_TABLE_CORRIDA);
        db.execSQL(CREATE_TABLE_LOCALIZACAO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Apaga as tabelas e recria se a versão mudar
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOCALIZACAO);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CORRIDA);
        onCreate(db);
    }

}
