package com.example.appcorrida;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NovaCorridaActivity extends AppCompatActivity implements LocationListener, OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private Button btnStartStop;
    private TextView tvStatus;
    private TextView tvDistance;
    private TextView tvDuration;
    private TextView tvElevationGain;

    private LocationManager locationManager;
    private boolean isRunning = false;
    private List<Location> points = new ArrayList<>();

    private GoogleMap googleMap;
    private Marker currentLocationMarker;
    private Polyline routePolyline;

    private long startTimeMillis = 0;
    private double totalDistanceMeters = 0;
    private double elevationGainMeters = 0;

    private Handler handler;
    private Runnable updateTimerRunnable;

    private AppDatabaseHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_corrida);

        btnStartStop = findViewById(R.id.btnStartStop);
        tvStatus = findViewById(R.id.tvStatus);
        tvDistance = findViewById(R.id.tvDistance);
        tvDuration = findViewById(R.id.tvDuration);
        tvElevationGain = findViewById(R.id.tvElevationGain);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        dbHelper = new AppDatabaseHelper(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        btnStartStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRunning) {
                    stopTracking();
                } else {
                    startTracking();
                }
            }
        });

        handler = new Handler();
        updateTimerRunnable = new Runnable() {
            @Override
            public void run() {
                if (isRunning) {
                    updateUI();
                    handler.postDelayed(this, 1000);
                }
            }
        };
    }

    private void startTracking() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        isRunning = true;
        btnStartStop.setText("Parar Corrida");
        tvStatus.setText("Status: Gravando...");

        points.clear();
        totalDistanceMeters = 0;
        elevationGainMeters = 0;
        startTimeMillis = SystemClock.elapsedRealtime();

        if (googleMap != null) {
            googleMap.clear(); // Limpa quaisquer marcadores/linhas de corridas anteriores
            currentLocationMarker = null; // Reinicia o marcador
            routePolyline = null; // Reinicia a polilinha
        }

        updateUI();

        handler.post(updateTimerRunnable);

        // Solicita atualizações de localização
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);
        Toast.makeText(this, "Rastreamento iniciado!", Toast.LENGTH_SHORT).show();
    }

    private void stopTracking() {
        isRunning = false;
        btnStartStop.setText("Iniciar Corrida");
        tvStatus.setText("Status: Parado");

        locationManager.removeUpdates(this);
        handler.removeCallbacks(updateTimerRunnable);
        updateUI();

        if (!points.isEmpty()) {
            long durationSeconds = (SystemClock.elapsedRealtime() - startTimeMillis) / 1000;
            long corridaId = dbHelper.insertCorrida(durationSeconds, totalDistanceMeters, elevationGainMeters);

            if (corridaId != -1) {
                dbHelper.insertPontosCorrida(corridaId, points, startTimeMillis);
                Toast.makeText(this, "Corrida salva! ID: " + corridaId, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Erro ao salvar a corrida.", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Nenhum ponto registrado. Corrida não salva.", Toast.LENGTH_LONG).show();
        }
    }

    private void updateUI() {
        long elapsedMillis = 0;
        if (startTimeMillis > 0) {
            elapsedMillis = SystemClock.elapsedRealtime() - startTimeMillis;
        }

        int seconds = (int) (elapsedMillis / 1000);
        int minutes = seconds / 60;
        int hours = minutes / 60;
        seconds = seconds % 60;
        minutes = minutes % 60;

        tvDuration.setText(String.format(Locale.getDefault(), "Duração: %02d:%02d:%02d", hours, minutes, seconds));
        tvDistance.setText(String.format(Locale.getDefault(), "Distância: %.2f km", totalDistanceMeters / 1000));
        tvElevationGain.setText(String.format(Locale.getDefault(), "Ganho de Elevação: %.1f m", elevationGainMeters));
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Tenta iniciar o rastreamento novamente se a permissão foi concedida
                startTracking();
                // E também tenta mover a câmera para a localização atual se o mapa já estiver pronto
                if (googleMap != null) {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        googleMap.setMyLocationEnabled(true);
                        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
                        // Tenta ir para a última localização conhecida após a permissão
                        Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        if (lastKnownLocation != null) {
                            LatLng lastLatLng = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lastLatLng, 17)); // Zoom detalhado
                            // Cria o marcador inicial se ainda não existir
                            if (currentLocationMarker == null) {
                                currentLocationMarker = googleMap.addMarker(new MarkerOptions().position(lastLatLng).title("Sua Posição").flat(true));
                            } else {
                                currentLocationMarker.setPosition(lastLatLng);
                            }
                            if (lastKnownLocation.hasBearing()) {
                                currentLocationMarker.setRotation(lastKnownLocation.getBearing());
                            }
                        }
                    }
                }
            } else {
                Toast.makeText(this, "Permissão de localização negada. Não é possível rastrear a corrida.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        if (!points.isEmpty()) {
            Location lastLocation = points.get(points.size() - 1);
            totalDistanceMeters += lastLocation.distanceTo(location);

            double elevationDiff = location.getAltitude() - lastLocation.getAltitude();
            if (elevationDiff > 0) {
                elevationGainMeters += elevationDiff;
            }
        }

        points.add(location);
        tvStatus.setText("Status: Gravando... Pontos: " + points.size() + " Lat: " + String.format("%.4f", location.getLatitude()) + " Lon: " + String.format("%.4f", location.getLongitude()));

        if (googleMap != null) {
            LatLng newLatLng = new LatLng(location.getLatitude(), location.getLongitude());

            // Atualiza ou cria o marcador de localização atual
            if (currentLocationMarker == null) {
                // Ao criar pela primeira vez, use flat(true) para rotação e defina a posição
                currentLocationMarker = googleMap.addMarker(new MarkerOptions().position(newLatLng).title("Sua Posição").flat(true));
            } else {
                currentLocationMarker.setPosition(newLatLng);
            }

            // Gira o marcador para a direção do movimento, se disponível
            if (location.hasBearing()) {
                currentLocationMarker.setRotation(location.getBearing());
            }

            // Move a câmera para a nova localização
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(newLatLng, 17));
            // Apenas move a câmera para a primeira atualização para evitar saltos.
            // Para zoom constante, remover este if, mas animateCamera já é suave.
            // if (points.size() == 1) { // Apenas para o primeiro ponto
            //     googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(newLatLng, 17));
            // } else {
            //     googleMap.animateCamera(CameraUpdateFactory.newLatLng(newLatLng));
            // }


            // Desenha o tracejado da rota
            if (routePolyline == null) {
                PolylineOptions polylineOptions = new PolylineOptions()
                        .add(newLatLng)
                        .color(ContextCompat.getColor(this, R.color.purple_500))
                        .width(10);
                routePolyline = googleMap.addPolyline(polylineOptions);
            } else {
                List<LatLng> currentPoints = routePolyline.getPoints();
                currentPoints.add(newLatLng);
                routePolyline.setPoints(currentPoints);
            }
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) { }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        Toast.makeText(this, "GPS habilitado!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        Toast.makeText(this, "GPS desabilitado. Por favor, habilite o GPS para rastrear.", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isRunning) {
            locationManager.removeUpdates(this);
            handler.removeCallbacks(updateTimerRunnable);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isRunning) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                startTracking(); // Esta chamada já reinicia o rastreamento e o timer.
            }
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true); // Mostra o ponto azul de localização
            googleMap.getUiSettings().setMyLocationButtonEnabled(true); // Habilita o botão de centralizar

            // Tenta ir para a última localização conhecida
            Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (lastKnownLocation != null) {
                LatLng lastLatLng = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lastLatLng, 17)); // Zoom detalhado na última localização
                // Cria o marcador inicial se ainda não existir
                if (currentLocationMarker == null) {
                    currentLocationMarker = googleMap.addMarker(new MarkerOptions().position(lastLatLng).title("Sua Posição").flat(true));
                } else {
                    currentLocationMarker.setPosition(lastLatLng);
                }
                if (lastKnownLocation.hasBearing()) {
                    currentLocationMarker.setRotation(lastKnownLocation.getBearing());
                }
            } else {
                // Fallback: se não houver última localização, vai para Salvador
                LatLng salvador = new LatLng(-12.9714, -38.5011);
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(salvador, 10));
            }
        } else {
            // Se a permissão não foi concedida, vai para Salvador como fallback
            LatLng salvador = new LatLng(-12.9714, -38.5011);
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(salvador, 10));
        }
    }
}