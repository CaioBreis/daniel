// pega os dados da consulta ao banco de dados, e preenche no List View
package com.example.appcorrida;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import java.util.Locale;

public class CorridaCursorAdapter extends CursorAdapter {

    public CorridaCursorAdapter(Context context, Cursor c) {
        super(context, c, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        // Infla o layout para um novo item da lista
        return LayoutInflater.from(context).inflate(R.layout.list_item_corrida, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        // Encontra os TextViews no layout do item
        TextView tvCorridaData = view.findViewById(R.id.tvCorridaData);
        TextView tvCorridaDuracao = view.findViewById(R.id.tvCorridaDuracao);
        TextView tvCorridaDistancia = view.findViewById(R.id.tvCorridaDistancia);
        TextView tvCorridaElevacao = view.findViewById(R.id.tvCorridaElevacao);

        // Obter os dados do Cursor usando as constantes do AppDatabaseHelper
        // (Certifique-se de que AppDatabaseHelper.java está atualizado com as constantes)
        String data = cursor.getString(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_DATA_HORA_INICIO));
        long duracaoSegundos = cursor.getLong(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_DURACAO_SEGUNDOS));
        double distanciaMetros = cursor.getDouble(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_DISTANCIA_METROS));
        double ganhoElevacao = cursor.getDouble(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_GANHO_ELEVACAO));

        // Formatar a duração para HH:MM:SS
        int seconds = (int) (duracaoSegundos % 60);
        int minutes = (int) ((duracaoSegundos / 60) % 60);
        int hours = (int) (duracaoSegundos / 3600);
        String formattedDuration = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);

        // Define o texto nos TextViews
        tvCorridaData.setText("Data: " + data);
        tvCorridaDuracao.setText("Duração: " + formattedDuration);
        tvCorridaDistancia.setText(String.format(Locale.getDefault(), "Distância: %.2f km", distanciaMetros / 1000));
        tvCorridaElevacao.setText(String.format(Locale.getDefault(), "Ganho de Elevação: %.1f m", ganhoElevacao));
    }
}