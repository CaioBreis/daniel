package com.example.appcorrida;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NovaCorridaActivity extends AppCompatActivity implements LocationListener, OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private Button btnStartStop;
    private TextView tvStatus;
    private TextView tvDistance;
    private TextView tvDuration;
    private TextView tvElevationGain;

    private LocationManager locationManager;
    private boolean isRunning = false;
    private List<Location> points = new ArrayList<>();

    private GoogleMap googleMap;
    private Marker currentLocationMarker;
    private Polyline routePolyline;

    private long startTimeMillis = 0;
    private double totalDistanceMeters = 0;
    private double elevationGainMeters = 0;

    private Handler handler;
    private Runnable updateTimerRunnable;

    private AppDatabaseHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_corrida);

        btnStartStop = findViewById(R.id.btnStartStop);
        tvStatus = findViewById(R.id.tvStatus);
        tvDistance = findViewById(R.id.tvDistance);
        tvDuration = findViewById(R.id.tvDuration);
        tvElevationGain = findViewById(R.id.tvElevationGain);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        dbHelper = new AppDatabaseHelper(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        btnStartStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRunning) {
                    stopTracking();
                } else {
                    startTracking();
                }
            }
        });

        handler = new Handler();
        updateTimerRunnable = new Runnable() {
            @Override
            public void run() {
                if (isRunning) {
                    updateUI();
                    handler.postDelayed(this, 1000);
                }
            }
        };
    }

    private void startTracking() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        isRunning = true;
        btnStartStop.setText(R.string.stop_run_button); // Usando string resource
        tvStatus.setText(R.string.status_recording); // Usando string resource

        points.clear();
        totalDistanceMeters = 0;
        elevationGainMeters = 0;
        startTimeMillis = SystemClock.elapsedRealtime();

        if (googleMap != null) {
            googleMap.clear();
            currentLocationMarker = null;
            routePolyline = null;
        }

        updateUI();

        handler.post(updateTimerRunnable);

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);
        Toast.makeText(this, R.string.rastreamento_iniciado, Toast.LENGTH_SHORT).show(); // Usando string resource
    }

    private void stopTracking() {
        isRunning = false;
        btnStartStop.setText(R.string.start_run_button); // Usando string resource
        tvStatus.setText(R.string.status_stopped); // Usando string resource

        locationManager.removeUpdates(this);
        handler.removeCallbacks(updateTimerRunnable);
        updateUI();

        if (!points.isEmpty()) {
            long durationSeconds = (SystemClock.elapsedRealtime() - startTimeMillis) / 1000;
            long corridaId = dbHelper.insertCorrida(durationSeconds, totalDistanceMeters, elevationGainMeters);

            if (corridaId != -1) {
                Toast.makeText(this, getString(R.string.corrida_salva_id, corridaId), Toast.LENGTH_LONG).show(); // Usando string resource com formato
                dbHelper.insertPontosCorrida(corridaId, points, startTimeMillis);
            } else {
                Toast.makeText(this, R.string.erro_salvar_corrida, Toast.LENGTH_LONG).show(); // Usando string resource
            }
        } else {
            Toast.makeText(this, R.string.nenhum_ponto_registrado_nao_salva, Toast.LENGTH_LONG).show(); // Usando string resource
        }
    }

    private void updateUI() {
        long elapsedMillis = 0;
        if (startTimeMillis > 0) {
            elapsedMillis = SystemClock.elapsedRealtime() - startTimeMillis;
        }

        int seconds = (int) (elapsedMillis / 1000);
        int minutes = seconds / 60;
        int hours = minutes / 60;
        seconds = seconds % 60;
        minutes = minutes % 60;

        tvDuration.setText(getString(R.string.duration_label, hours, minutes, seconds)); // Usando string resource com formato
        tvDistance.setText(getString(R.string.distance_label, totalDistanceMeters / 1000)); // Usando string resource com formato
        tvElevationGain.setText(getString(R.string.elevation_gain_label, elevationGainMeters)); // Usando string resource com formato
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startTracking();
                if (googleMap != null) {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        googleMap.setMyLocationEnabled(true);
                        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
                        Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        if (lastKnownLocation != null) {
                            LatLng lastLatLng = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lastLatLng, 17));
                            if (currentLocationMarker == null) {
                                currentLocationMarker = googleMap.addMarker(new MarkerOptions().position(lastLatLng).title(getString(R.string.your_position)).flat(true)); // Usando string resource
                            } else {
                                currentLocationMarker.setPosition(lastLatLng);
                            }
                            if (lastKnownLocation.hasBearing()) {
                                currentLocationMarker.setRotation(lastKnownLocation.getBearing());
                            }
                        }
                    }
                }
            } else {
                Toast.makeText(this, R.string.permissao_localizacao_negada, Toast.LENGTH_LONG).show(); // Usando string resource
            }
        }
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        if (!points.isEmpty()) {
            Location lastLocation = points.get(points.size() - 1);
            totalDistanceMeters += lastLocation.distanceTo(location);

            double elevationDiff = location.getAltitude() - lastLocation.getAltitude();
            if (elevationDiff > 0) {
                elevationGainMeters += elevationDiff;
            }
        }

        points.add(location);
        tvStatus.setText(getString(R.string.status_recording) + " Pontos: " + points.size() + " Lat: " + String.format("%.4f", location.getLatitude()) + " Lon: " + String.format("%.4f", location.getLongitude()));


        if (googleMap != null) {
            LatLng newLatLng = new LatLng(location.getLatitude(), location.getLongitude());

            if (currentLocationMarker == null) {
                currentLocationMarker = googleMap.addMarker(new MarkerOptions().position(newLatLng).title(getString(R.string.your_position)).flat(true)); // Usando string resource
            } else {
                currentLocationMarker.setPosition(newLatLng);
            }

            if (location.hasBearing()) {
                currentLocationMarker.setRotation(location.getBearing());
            }

            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(newLatLng, 17));

            if (routePolyline == null) {
                PolylineOptions polylineOptions = new PolylineOptions()
                        .add(newLatLng)
                        .color(ContextCompat.getColor(this, R.color.purple_500))
                        .width(10);
                routePolyline = googleMap.addPolyline(polylineOptions);
            } else {
                List<LatLng> currentPoints = routePolyline.getPoints();
                currentPoints.add(newLatLng);
                routePolyline.setPoints(currentPoints);
            }
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) { }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        Toast.makeText(this, R.string.gps_habilitado, Toast.LENGTH_SHORT).show(); // Usando string resource
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        Toast.makeText(this, R.string.gps_desabilitado, Toast.LENGTH_LONG).show(); // Usando string resource
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isRunning) {
            locationManager.removeUpdates(this);
            handler.removeCallbacks(updateTimerRunnable);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isRunning) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                startTracking();
            }
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);
            googleMap.getUiSettings().setMyLocationButtonEnabled(true);

            Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (lastKnownLocation != null) {
                LatLng lastLatLng = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lastLatLng, 17));
                if (currentLocationMarker == null) {
                    currentLocationMarker = googleMap.addMarker(new MarkerOptions().position(lastLatLng).title(getString(R.string.your_position)).flat(true)); // Usando string resource
                } else {
                    currentLocationMarker.setPosition(lastLatLng);
                }
                if (lastKnownLocation.hasBearing()) {
                    currentLocationMarker.setRotation(lastKnownLocation.getBearing());
                }
            } else {
                LatLng salvador = new LatLng(-12.9714, -38.5011);
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(salvador, 10));
            }
        } else {
            LatLng salvador = new LatLng(-12.9714, -38.5011);
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(salvador, 10));
        }
    }
}