package com.example.appcorrida;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
public class ListaCorridasActivity extends AppCompatActivity {
    private ListView listViewCorridas;
    private ArrayList<String> corridas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_corridas);

        listViewCorridas = findViewById(R.id.listViewCorridas);

        // Exemplo de corridas simuladas (serão substituídas por dados reais depois)
        corridas = new ArrayList<>();
        corridas.add("Corrida em Salvador - 5 km");
        corridas.add("Corrida no Parque - 3.2 km");
        corridas.add("Corrida na Orla - 7 km");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                corridas
        );

        listViewCorridas.setAdapter(adapter);
    }

}
