package com.example.appcorrida;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AppDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "corridas.db";
    private static final int DATABASE_VERSION = 1;

    // Nomes das colunas da tabela CORRIDAS
    public static final String TABLE_NAME = "CORRIDAS";
    public static final String COLUMN_ID = "_id"; // CORREÇÃO AQUI: Mudado para "_id" em minúsculas
    public static final String COLUMN_DATA = "DATA"; // Coluna para a data/hora da corrida
    public static final String COLUMN_DISTANCIA = "DISTANCIA"; // Coluna para a distância percorrida (em metros, por exemplo)
    public static final String COLUMN_TEMPO_PERCORRIDO = "TEMPO_PERCORRIDO"; // Coluna para a duração da corrida (em segundos)
    public static final String COLUMN_RITMO_MEDIO = "RITMO_MEDIO"; // Coluna para o ritmo médio
    public static final String COLUMN_GANHO_ELEVACAO = "GANHO_ELEVACAO"; // Nova coluna para ganho de elevação


    public AppDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CORRIDAS_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_DATA + " TEXT,"
                + COLUMN_DISTANCIA + " REAL,"
                + COLUMN_TEMPO_PERCORRIDO + " INTEGER,"
                + COLUMN_RITMO_MEDIO + " REAL,"
                + COLUMN_GANHO_ELEVACAO + " REAL" +
                ")";
        db.execSQL(CREATE_CORRIDAS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Método para inserir uma nova corrida
    public long insertCorrida(long durationSeconds, double totalDistanceMeters, double elevationGainMeters) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Formatar a data/hora atual
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String currentDateandTime = sdf.format(new Date());

        values.put(COLUMN_DATA, currentDateandTime);
        values.put(COLUMN_DISTANCIA, totalDistanceMeters);
        values.put(COLUMN_TEMPO_PERCORRIDO, durationSeconds);
        values.put(COLUMN_GANHO_ELEVACAO, elevationGainMeters);

        // Calcular ritmo médio (metros por segundo -> minutos por km)
        double ritmoMedio = 0.0;
        if (totalDistanceMeters > 0 && durationSeconds > 0) {
            ritmoMedio = (durationSeconds / 60.0) / (totalDistanceMeters / 1000.0); // min/km
        }
        values.put(COLUMN_RITMO_MEDIO, ritmoMedio);

        long id = db.insert(TABLE_NAME, null, values);
        db.close();
        return id;
    }

    // Método placeholder para inserir pontos de corrida.
    // Atualmente, não há uma tabela separada para pontos.
    // Se você precisar armazenar cada ponto da corrida, uma nova tabela com chave estrangeira
    // para CORRIDAS precisaria ser criada.
    public void insertPontosCorrida(long corridaId, List<Location> points, long startTimeMillis) {
        // Log para indicar que esta função foi chamada.
        Log.d("AppDatabaseHelper", "insertPontosCorrida chamado para Corrida ID: " + corridaId + " com " + points.size() + " pontos.");
        // Exemplo: se você quiser salvar uma representação simples no log
        /*
        for (Location point : points) {
            Log.d("AppDatabaseHelper", "Ponto: Lat " + point.getLatitude() + ", Lon " + point.getLongitude());
        }
        */
        // Se você precisa salvar estes pontos, você precisará:
        // 1. Criar uma nova tabela no onCreate, ex: TABLE_PONTOS (ID INTEGER PRIMARY KEY, CORRIDA_ID INTEGER, LAT REAL, LON REAL, ... FOREIGN KEY CORRIDA_ID REFERENCES CORRIDAS(ID))
        // 2. Implementar a lógica de inserção aqui.
    }


    // Método para obter todas as corridas do banco de dados
    public Cursor getAllCorridas() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                COLUMN_ID, // Agora será "_id"
                COLUMN_DATA,
                COLUMN_DISTANCIA,
                COLUMN_TEMPO_PERCORRIDO,
                COLUMN_RITMO_MEDIO,
                COLUMN_GANHO_ELEVACAO
        };
        // O último parâmetro de 'query' é o 'orderBy', ordenando pela data em ordem decrescente
        return db.query(
                TABLE_NAME,
                projection,
                null, // selection (WHERE clause)
                null, // selectionArgs
                null, // groupBy
                null, // having
                COLUMN_DATA + " DESC" // orderBy (ordenar pela data mais recente primeiro)
        );
    }
}