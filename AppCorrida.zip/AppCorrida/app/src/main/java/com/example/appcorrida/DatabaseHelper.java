//Gerencia as tabelas CORRIDA e LOCALIZAÇÃO; relaciona as localizações com cada corrida.
package com.example.appcorrida;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper{
    public static final String NOME_BANCO = "corridas.db";
    public static final int VERSAO = 1;

    public static final String TABELA_CORRIDA = "corrida";
    public static final String TABELA_LOCALIZACAO = "localizacao";

    public DatabaseHelper(Context context) {
        super(context, NOME_BANCO, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Criação da tabela corrida
        db.execSQL(
                "CREATE TABLE " + TABELA_CORRIDA + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "data TEXT NOT NULL, " +
                        "duracao TEXT NOT NULL, " +
                        "distancia REAL NOT NULL, " +
                        "ganho_elevacao REAL NOT NULL" +
                        ");"
        );

        // Criação da tabela localizacao
        db.execSQL(
                "CREATE TABLE " + TABELA_LOCALIZACAO + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "corrida_id INTEGER NOT NULL, " +
                        "latitude REAL NOT NULL, " +
                        "longitude REAL NOT NULL, " +
                        "elevacao REAL, " +
                        "timestamp TEXT NOT NULL, " +
                        "FOREIGN KEY (corrida_id) REFERENCES " + TABELA_CORRIDA + "(id) ON DELETE CASCADE" +
                        ");"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABELA_LOCALIZACAO);
        db.execSQL("DROP TABLE IF EXISTS " + TABELA_CORRIDA);
        onCreate(db);
    }

}
