package com.example.appcorrida;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ListaCorridasActivity extends AppCompatActivity {

    private ListView listViewCorridas;
    private TextView tvEmptyListMessage;
    private AppDatabaseHelper dbHelper;
    private CorridaCursorAdapter cursorAdapter;
    private Cursor corridasCursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_corridas);

        listViewCorridas = findViewById(R.id.listViewCorridas);
        tvEmptyListMessage = findViewById(R.id.tvEmptyListMessage);
        dbHelper = new AppDatabaseHelper(this);

        listViewCorridas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(ListaCorridasActivity.this, getString(R.string.run_clicked_id, id), Toast.LENGTH_SHORT).show(); // Usando string resource com formato
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCorridasFromDatabase();
    }

    private void loadCorridasFromDatabase() {
        if (corridasCursor != null && !corridasCursor.isClosed()) {
            corridasCursor.close();
        }
        corridasCursor = dbHelper.getAllCorridas();

        if (corridasCursor != null && corridasCursor.getCount() > 0) {
            if (cursorAdapter == null) {
                cursorAdapter = new CorridaCursorAdapter(this, corridasCursor);
                listViewCorridas.setAdapter(cursorAdapter);
            } else {
                cursorAdapter.changeCursor(corridasCursor);
            }
            listViewCorridas.setVisibility(View.VISIBLE);
            tvEmptyListMessage.setVisibility(View.GONE);
        } else {
            if (cursorAdapter != null) {
                cursorAdapter.changeCursor(null);
            } else {
                listViewCorridas.setAdapter(null);
            }
            listViewCorridas.setVisibility(View.GONE);
            tvEmptyListMessage.setVisibility(View.VISIBLE);
            Toast.makeText(this, R.string.no_runs_yet, Toast.LENGTH_SHORT).show(); // Usando string resource
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (corridasCursor != null && !corridasCursor.isClosed()) {
            corridasCursor.close();
        }
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}