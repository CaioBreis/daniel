package com.example.appcorrida;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import java.util.Locale;

public class CorridaCursorAdapter extends CursorAdapter {

    public CorridaCursorAdapter(Context context, Cursor c) {
        super(context, c, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item_corrida, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView tvCorridaData = view.findViewById(R.id.tvCorridaData);
        TextView tvCorridaDuracao = view.findViewById(R.id.tvCorridaDuracao);
        TextView tvCorridaDistancia = view.findViewById(R.id.tvCorridaDistancia);
        TextView tvCorridaElevacao = view.findViewById(R.id.tvCorridaElevacao);

        // Usando as constantes corretas do AppDatabaseHelper para obter os índices das colunas
        String data = cursor.getString(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_DATA));
        long duracaoSegundos = cursor.getLong(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_TEMPO_PERCORRIDO));
        double distanciaMetros = cursor.getDouble(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_DISTANCIA));

        double ganhoElevacao = 0.0;
        try {
            // Tenta obter a coluna GANHO_ELEVACAO. Se não existir, o valor padrão (0.0) será mantido.
            ganhoElevacao = cursor.getDouble(cursor.getColumnIndexOrThrow(AppDatabaseHelper.COLUMN_GANHO_ELEVACAO));
        } catch (IllegalArgumentException e) {
            // Opcional: logar que a coluna não foi encontrada, mas não é um erro crítico se ela for opcional
            // Log.e("CorridaCursorAdapter", "Coluna GANHO_ELEVACAO não encontrada. Usando valor padrão 0.0", e);
        }


        int seconds = (int) (duracaoSegundos % 60);
        int minutes = (int) ((duracaoSegundos / 60) % 60);
        int hours = (int) (duracaoSegundos / 3600);

        // Formatar e definir o texto usando os recursos de string com placeholders
        tvCorridaData.setText(context.getString(R.string.run_data_label, data));
        tvCorridaDuracao.setText(context.getString(R.string.duration_label, hours, minutes, seconds));
        tvCorridaDistancia.setText(context.getString(R.string.distance_label, distanciaMetros / 1000.0)); // Converte metros para quilômetros
        tvCorridaElevacao.setText(context.getString(R.string.elevation_gain_label, ganhoElevacao));
    }
}